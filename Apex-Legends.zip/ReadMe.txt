Apex Legends APK Release 1.5

- Updated: Feb 12,2019
- Requires Android 4.1 and above
- Size: 58.0 MB
- Developer: Respawn Entertainment
- Content Rating: Everyone

The APK File is locked because we don't want anyone to MOD it or distribute it without our permission!

To get the password for zip,
Go to Link: https://filesenzu.com/pw

To unlock the password, you have to complete a short survey for human verification purposes.
Bots can not unlock this!
