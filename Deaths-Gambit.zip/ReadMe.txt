Death's Gambit Release 1.0

- Updated: Dec 5,2018
- Requires Android 4.1 and above
- Size: 13.7MB
- Developer: Adult Swim Games
- Content Rating: Everyone


> How to Install Death's Gambit apk?

- Tap on Deaths-Gambit.apk
- Allow apps from the target source
- Tap on INSTALL
- After it's installed, Tap on Death's Gambit found on your Launcher

> Additional Information

- Complete any surveys/offers required by the game for verification purposes.
- These OFFERS are FREE and can be completed in 1-5 minutes.
- This helps the developers get a specific idea about the demographics.
