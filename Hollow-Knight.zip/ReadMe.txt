Hollow Knight Release 1.0

- Updated: Dec 5,2018
- Requires Android 4.1 and above
- Size: 17.2MB
- Developer: Team Cherry
- Content Rating: Everyone


> How to Install Hollow Knight apk?

- Tap on Hollow Knight.apk
- Allow apps from the target source
- Tap on INSTALL
- After it's installed, Tap on Hollow Knight found on your Launcher

> Additional Information

- Complete any surveys/offers required by the game for verification purposes.
- These OFFERS are FREE and can be completed in 1-5 minutes.
- This helps the developers get a specific idea about the demographics.
