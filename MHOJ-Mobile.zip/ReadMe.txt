My Hero One's Justice Release 1.0

- Updated: Dec 9,2018
- Requires Android 4.1 and above
- Size: 38.4MB
- Developer: bandai
- Content Rating: Everyone


> How to Install My Hero One's Justice apk?

- Tap on MHOJ-Mobile.apk
- Allow apps from the target source
- Tap on INSTALL
- After it's installed, Tap on My Hero One's Justice found on your Launcher

> Additional Information

- Complete any surveys/offers required by the game for verification purposes.
- These OFFERS are FREE and can be completed in 1-5 minutes.
- This helps the developers get a specific idea about the demographics.
